package com.green.cafe.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.green.cafe.dao.PostDao;
import com.green.cafe.dto.PostDto;
import com.green.cafe.dto.SearchCriteria;

@Service("PostService")
public class PostServiceImpl implements PostService {
	
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public ArrayList<PostDto> list(SearchCriteria scri) throws Exception {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		ArrayList<PostDto> list = dao.list(scri);

		return list;
	}

	@Override
	public void write(HashMap<String, String> param) throws Exception {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		dao.write(param);
	}

	@Override
	public PostDto contentView(HashMap<String, String> param) throws Exception {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		PostDto dto = dao.contentView(param);
		return dto;
	}

	@Override
	public void modify(HashMap<String, String> param) throws Exception {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		dao.modify(param);
	}

	@Override
	public void delete(HashMap<String, String> param) throws Exception {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		dao.delete(param);
	}

	@Override
	public int listCount(SearchCriteria scri) throws Exception {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		return dao.listCount(scri);
	}

}
