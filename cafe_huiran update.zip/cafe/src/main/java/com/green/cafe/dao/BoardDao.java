package com.green.cafe.dao;

import java.util.List;

import com.green.cafe.dto.BoardDto;

public interface BoardDao {
	public void create(BoardDto dto) throws Exception;
	public BoardDto read(int post_no) throws Exception;
	public void update(BoardDto dto) throws Exception;
	public void delete(int post_no) throws Exception;
	public List<BoardDto> listAll() throws Exception;
	public void increaseViewcnt(int post_no) throws Exception;
}
