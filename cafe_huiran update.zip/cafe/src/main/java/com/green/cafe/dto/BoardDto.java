package com.green.cafe.dto;

public class BoardDto{
	private int post_no;
	private String post_writer;
	private String post_title;
	private String post_content;
	private int post_hit;
	private int post_like;
	private int post_regdate;
	private int post_moddate;
	
	public int getPost_no() {
		return post_no;
	}
	public void setPost_no(int post_no) {
		this.post_no = post_no;
	}
	public String getPost_writer() {
		return post_writer;
	}
	public void setPost_writer(String post_writer) {
		this.post_writer = post_writer;
	}
	public String getPost_title() {
		return post_title;
	}
	public void setPost_title(String post_title) {
		this.post_title = post_title;
	}
	public String getPost_content() {
		return post_content;
	}
	public void setPost_content(String post_content) {
		this.post_content = post_content;
	}
	public int getPost_hit() {
		return post_hit;
	}
	public void setPost_hit(int post_hit) {
		this.post_hit = post_hit;
	}
	public int getPost_like() {
		return post_like;
	}
	public void setPost_like(int post_like) {
		this.post_like = post_like;
	}
	public int getPost_regdate() {
		return post_regdate;
	}
	public void setPost_regdate(int post_regdate) {
		this.post_regdate = post_regdate;
	}
	public int getPost_moddate() {
		return post_moddate;
	}
	public void setPost_moddate(int post_moddate) {
		this.post_moddate = post_moddate;
	}
}
