package com.green.cafe.service;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.green.cafe.dao.BoardDao;
import com.green.cafe.dto.BoardDto;


@Repository
public class BoardServiceImpl implements BoardDao{
	@Inject
	SqlSession sqlSession;

	@Override
	public void create(BoardDto dto) throws Exception {
		sqlSession.insert("board.insert", dto);
	}

	@Override
	public BoardDto read(int post_no) throws Exception {
		return sqlSession.selectOne("board.view", post_no);
	}

	@Override
	public void update(BoardDto dto) throws Exception {
		sqlSession.update("board.updateArticle", dto);
	}

	@Override
	public void delete(int post_no) throws Exception {
		sqlSession.delete("board.deleteArticle", post_no);
	}

	@Override
	public List<BoardDto> listAll() throws Exception {
		return sqlSession.selectList("board.listAll");
	}

	@Override
	public void increaseViewcnt(int post_no) throws Exception {
		sqlSession.delete("board.increaseViewcnt", post_no);	
	}
}
