package com.green.cafe.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.green.cafe.dto.MemDto;
import com.green.cafe.service.MemService;

@Controller
@RequestMapping("/member")
public class MemController {

	@Autowired
	private MemService service;
	
	@RequestMapping("/login") //로그인폼
	public String login() {
		System.out.println("@@@### LOGIN()");
		
		return "member/login";
	}
	
	@RequestMapping("/loginYn") //로그인 처리 -> MemServiceImpl.java
	public String loginYn(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### loginYN()");
		
		int re = service.loginYn(param);
		if(re==1) {
			ArrayList<MemDto> dtos = service.loginView(param);
			model.addAttribute("loginView",dtos);
			
			if(dtos.get(0).getMem_days() >= 7) {
			//로그인할때 가입 후 경과일이 7일 이상시 lv.1에서 lv.2로 등급변경
				System.out.println("autoLv.UP_success!");
				service.levelUp_auto(param);
				dtos = service.loginView(param);
				model.addAttribute("loginView",dtos);
			}
			return "member/login_ok";
		}
		return "redirect:login";
	}
	
	@RequestMapping("/register") //회원가입
	public String register() {
		System.out.println("@@@### register");
		
		return "member/register";
	}
	
	@RequestMapping("/registerOk") //테이블 insert -> MemServiceImpl.java
	public String registerOk(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### registerOk");
		service.register(param);
		
		System.out.println("회원등록완료->로그인 페이지로 이동됩니다.");
		return "redirect:login";
	}
	
	@RequestMapping("/updateInfo") //회원정보 수정 폼
	public String updateInfo(@RequestParam HashMap<String, String> param,Model model) {
		System.out.println("@@@### updateInfo");
		ArrayList<MemDto> dtos = service.loginView(param);
		model.addAttribute("loginView",dtos);//회원아이디로 전체 정보를 조회하기 위해 넘김
		return "member/updateInfo";
	}
	
	@RequestMapping("/updateInfoOk") //회원정보 수정 처리 update -> MemServiceImpl.java
	public String updateInfoOk(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### updateInfoOk");
		service.updateInfo(param);
		System.out.println("회원정보 수정완료");
		ArrayList<MemDto> dtos = service.loginView(param);
		model.addAttribute("loginView",dtos);
		return "member/checkInfo";//정보 수정 후 checkInfo로 이동
	}
	
	@RequestMapping("/checkInfo") //회원 개인정보 조회 
	public String checkInfo(@RequestParam HashMap<String, String> param,Model model) {
		System.out.println("@@@### checkInfo");
		service.countDays();
		ArrayList<MemDto> dtos = service.loginView(param);
		model.addAttribute("loginView",dtos);//회원아이디로 전체 정보를 조회하기 위해 넘김
		
		return "member/checkInfo";
	}
	
	@RequestMapping("/memberView")//전체 회원조회
	public String memberView(Model model) {
		System.out.println("memberView");
		service.countDays();
		ArrayList<MemDto> dtos = service.memberView();
		model.addAttribute("MemberView",dtos);
		
		return "member/memberView";
	}
	
	@RequestMapping("/deleteMember") //회원탈퇴
	public String deleteMember(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### deleteMember");
		service.deleteMember(param);
		System.out.println("회원탈퇴완료");
		ArrayList<MemDto> dtos = service.loginView(param);
		//관리자의 회원관리 페이지에서 강퇴를 시킨 경우 memberView를 볼 수 있도록 설정
		if(dtos.get(0).getMem_id().equals("admin")) { 
			return "redirect:memberView";
		}
		return "redirect:login";	//관리자가 아닌 일반 회원의 경우 로그인 페이지로 이동
	}
	
	//관리자의 회원관리 페이지에서 등급을 올릴때 사용
	@RequestMapping("levelUp_admin")
	public String levelUp_admin(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("levelUp_admin");
		service.levelUp_admin(param);
		
		System.out.println(param+"의 등급이 Lv3이 되었습니다.");
		return "redirect:memberView";
	}
	//관리자의 회원관리 페이지에서 등급을 내릴때 사용
	@RequestMapping("levelDown_admin")
	public String levelDown_admin(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("levelDown_admin");
		service.levelDown_admin(param);
		
		System.out.println(param+"의 등급이 Lv2로 변경되었습니다.");
		return "redirect:memberView";
	}
	
}
