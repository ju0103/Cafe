package com.green.cafe.controller;

public class SessionConst {
	/**로그인 세션정보 저장*/
	public static final String LOGIN_MEMBER = "loginMember";
	
}
