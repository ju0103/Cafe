package com.green.cafe.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.green.cafe.dao.MemDao;
import com.green.cafe.dto.MemDto;

@Service("MemService")
public class MemServiceImpl implements MemService{

	@Autowired
	private SqlSession sqlSession;

	@Override
	public int loginYn(HashMap<String, String> param) {
		//�α��� : ���̵� ��� �´��� Ȯ��
		// TODO Auto-generated method stub
		MemDao dao = sqlSession.getMapper(MemDao.class);
		ArrayList<MemDto> dtos = dao.loginYn(param);
		
		int re = -1;
		if(!dtos.isEmpty()) {
			if (dtos.get(0).getMem_pw().equals(param.get("mem_pw"))) {
				re=1;
				System.out.println("�α��� ����!");
			} else {
				re=0;
				System.out.println("��й�ȣ ����ġ -> �Է°� : "+param.get("mem_pw"));
				System.out.println("�Է��ؾ��� ��й�ȣ : "+dtos.get(0).getMem_pw());
			}
		}else {
			 System.out.println("�������� �ʴ� ȸ���Դϴ�.");
		}
		return re;
	}
	
	@Override
	public void register(HashMap<String, String> param) {
		// TODO Auto-generated method stub
		MemDao dao = sqlSession.getMapper(MemDao.class);
		dao.register(param);
	}

	@Override
	public ArrayList<MemDto> memberView() {
		System.out.println("MSI/MV S");
		MemDao dao = sqlSession.getMapper(MemDao.class);
		ArrayList<MemDto> dtos = dao.memberView();
		System.out.println("MSI/MV E");
		return dtos;
	}

	@Override
	public void updateInfo(HashMap<String, String> param) {
		// TODO Auto-generated method stub
		MemDao dao = sqlSession.getMapper(MemDao.class);
		dao.updateInfo(param);
	}

	@Override
	public void checkInfo(HashMap<String, String> param) {
		// TODO Auto-generated method stub
		System.out.println("MSI/CI S");
		MemDao dao = sqlSession.getMapper(MemDao.class);
		dao.checkInfo(param);
		System.out.println("MSI/CI E");
	}
	@Override
	public void deleteMember(HashMap<String, String> param) {
		// TODO Auto-generated method stub
		MemDao dao = sqlSession.getMapper(MemDao.class);
		dao.deleteMember(param);
	}
	@Override
	public ArrayList<MemDto> loginView(HashMap<String, String> param) {
		// TODO Auto-generated method stub
		MemDao dao = sqlSession.getMapper(MemDao.class);
		ArrayList<MemDto> dtos = dao.loginView(param);
		return dtos;
	}

	@Override
	public void countDays() {
		// TODO Auto-generated method stub
		System.out.println("MSI/CD s");
		MemDao dao = sqlSession.getMapper(MemDao.class);
		dao.countDays();
		System.out.println("MSI/CD e");
	}

	@Override
	public void levelUp_auto(HashMap<String, String> param) {
		// TODO Auto-generated method stub
		MemDao dao = sqlSession.getMapper(MemDao.class);
		dao.levelUp_auto(param);
	}

	@Override
	public void levelUp_admin(HashMap<String, String> param) {
		// TODO Auto-generated method stub
		MemDao dao = sqlSession.getMapper(MemDao.class);
		dao.levelUp_admin(param);
	}

	@Override
	public void levelDown_admin(HashMap<String, String> param) {
		// TODO Auto-generated method stub
		MemDao dao = sqlSession.getMapper(MemDao.class);
		dao.levelDown_admin(param);
	}
}
