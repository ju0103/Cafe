package com.green.cafe_test.controller;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.green.cafe_test.dto.PageMaker;
import com.green.cafe_test.dto.PostDto;
import com.green.cafe_test.dto.SearchCriteria;
import com.green.cafe_test.service.PostService;

@Controller
@RequestMapping("/post")
public class PostController {

	@Autowired
	private PostService postService;
	
	// 게시물 작성
	@RequestMapping(value = "/post_write_view")
	public String post_write_view() throws IOException {
		System.out.println("===== post_write_view() =====");
		return "post/post_write_view";
	}
	
	// 게시물 등록
	@RequestMapping(value = "/post_write")
	public String post_write(@RequestParam HashMap<String, String> param, MultipartFile file, Model model) throws Exception {
		System.out.println("===== post_write() =====");
		postService.post_write(param, file);
		return "redirect:post_list";
	}
	
	// 게시물 목록 조회(페이징)
	@RequestMapping(value = "/post_list")
	public String post_list(Model model, @ModelAttribute("searchCriteria") SearchCriteria searchCriteria) {
		System.out.println("===== post_list() =====");
		
		ArrayList<PostDto> list = postService.post_list(searchCriteria);
		model.addAttribute("post_list", list);
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotalCount(postService.list_cnt(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);

		model.addAttribute("searchCriteria", searchCriteria);
		return "post/post_list";
	}
	
	// 게시물 상세 내용 조회
	@RequestMapping(value = "/post_content")
	public String post_content(@RequestParam HashMap<String, String> param, PostDto dto, Model model) {
		System.out.println("===== post_content() =====");
		
		// 게시물 조회 수 증가
		postService.update_view(param);

		model.addAttribute("post_content", postService.post_content(param));
		
		return "post/post_content";
	}
	
	// 게시물 수정 뷰
	@RequestMapping(value = "/post_update_view")
	public String post_update_view(@RequestParam HashMap<String, String> param, @ModelAttribute("searchCriteria") SearchCriteria searchCriteria, Model model) {
		System.out.println("===== post_update_view() =====");
		
		model.addAttribute("update_view", postService.post_content(param));
		
		return "post/post_update_view";
	}
	
	// 게시물 수정
	@RequestMapping(value = "/post_update")
	public String post_update(@RequestParam HashMap<String, String> param) {
		System.out.println("===== post_update() =====");
		postService.post_update(param);
		
		return "redirect:post_list";
	}
	
	// 게시물 삭제
	@RequestMapping(value = "/post_delete")
	public String post_delete(@RequestParam HashMap<String, String> param) {
		System.out.println("===== post_delete() =====");
		postService.post_delete(param);
		
		return "redirect:post_list";
	}
	
	// 첨부파일 다운로드
	@RequestMapping(value = "/download_file")
	public void download_file(@RequestParam HashMap<String, String> param, HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("===== download_file =====");
		String post_no = (String)param.get("post_no");
		String file_name = (String)param.get("file_name");
		System.out.println("post no >>" + post_no);
		System.out.println("file name >>" + file_name);
		
		System.out.println("=========================");
		PostDto postDto = postService.file_info(param);
		String regdate = postDto.getPost_regdate().toString().substring(0, 10).replaceAll("-", "");
		String orgFileName = postDto.getFile_name();
		String storedFileName = postDto.getStored_file_name();
		System.out.println("=============");
		System.out.println("파일 원본명: " + orgFileName);
		System.out.println("파일 서버명: " + storedFileName);
		System.out.println("저장일: " + regdate);
		System.out.println("=============");
		
		/**
		 * 전송할 파일을 byte 배열로 바꾸고,
		 * response의 출력 스트림을 이용하여 파일을 전송한 후
		 * 버퍼를 flush하고 요청을 종료한다.
		 * 파일 저장소: D:\\uploadFiles\\regdate\\서버에 저장된 파일 이름.
		 */
		byte[] fileByte = FileUtils.readFileToByteArray(new File("D:\\uploadFiles\\" + regdate + "\\" + storedFileName));
		
		response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
		response.setContentLength(fileByte.length);
		response.setHeader("Content-Disposition", "attachment; fileName=\"" + URLEncoder.encode(storedFileName, "UTF-8") + "\";");
		response.setHeader("Content-Transfer-Encoding", "binary");
		
		response.getOutputStream().write(fileByte);
		response.getOutputStream().flush();
		response.getOutputStream().close();
	}
}
