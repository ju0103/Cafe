package com.green.cafe_test.dto;

public class Criteria {
	/* 현재 페이지 */
	private int page;
	/* 한 페이지에 나타나는 페이지 수 */
	private int perPageNum;
	/* 페이지에 나타나는 게시물 중 첫번째 게시물의 rowNum (SQL 행 시작 번호) */
	private int rowStart;
	/* 페이지에 나타나는 게시물 중 마지막 게시물의 rowNum (SQL 행 끝 번호) */
	private int rowEnd;
	
	// 기본 생성자: 기본 페이지는 1, 페이지 당 보여지는 게시물 갯수는 10개
	public Criteria() {
		this.page = 1;
		this.perPageNum = 10;
	}
	
	public int getPage() {
		return page;
	}
	
	public void setPage(int page) {
		// 페이지가 0보다 작거나 같을 경우 현재 페이지 기본 값은 1
		if (page <= 0) {
			this.page = 1;
			return;
		}
		this.page = page;
	}
	
	public int getPerPageNum() {
		return perPageNum;
	}
	
	public void setPerPageNum(int perPageNum) {
		if (perPageNum <= 0 || perPageNum > 100) {
			this.perPageNum = 10;
			return;
		}
		this.perPageNum = perPageNum;
	}
	
	public int getRowStart() {
		this.rowStart = ((this.page - 1) * perPageNum) + 1;
		return this.rowStart;
	}
	
	public void setRowStart(int rowStart) {
		this.rowStart = rowStart;
	}
	
	public int getRowEnd() {
		this.rowEnd = this.rowStart + this.perPageNum - 1;
		return this.rowEnd;
	}
	
	public void setRowEnd(int rowEnd) {
		this.rowEnd = rowEnd;
	}
	
	@Override
	public String toString() {
		return "Criteria [page=" + page + ", perPageNum=" + perPageNum + ", rowStart=" + rowStart + ", rowEnd=" + rowEnd
				+ "]";
	}
}
