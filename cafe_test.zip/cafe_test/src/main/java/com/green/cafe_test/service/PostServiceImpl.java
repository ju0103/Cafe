package com.green.cafe_test.service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import com.green.cafe_test.dao.PostDao;
import com.green.cafe_test.dto.PostDto;
import com.green.cafe_test.dto.SearchCriteria;

@Service("PostService")
public class PostServiceImpl implements PostService {
	
	@Autowired
	private SqlSession sqlSession;

	private String base_path = "";
	
	// 게시글 작성
	@Override
	public void post_write(HashMap<String, String> param, MultipartFile file) throws Exception {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		
		// 원본 파일명
		String orgFileName = file.getOriginalFilename();
		// 확장자
		String extension = orgFileName.substring(orgFileName.lastIndexOf("."), orgFileName.length());
		// 랜덤한 파일명 생성
		UUID uuid = UUID.randomUUID();
		String storedFileName = uuid.toString() + extension;
		storedFileName = storedFileName.replaceAll("-", "");
		// 파일 크기
		long file_size = file.getSize();
		// 파일 데이터
		byte[] data = file.getBytes();
		
		mkDir();
		
		// File target = new File("D:\\uploadFiles", orgFileName);
		File target = new File(base_path + "\\", storedFileName);
		
		try {
			FileCopyUtils.copy(data, target);
		} catch (Exception e) {
			e.printStackTrace();
		}
		param.put("file_name", orgFileName);
		param.put("stored_file_name", storedFileName);
		param.put("file_size", Long.toString(file_size));
		dao.post_write(param);
	}

	// 날짜별 디렉토리 생성
	@Override
	public void mkDir() {
		Calendar cal = Calendar.getInstance();
		Date now = new Date();
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		String regdate = formatter.format(now);
		System.out.println(regdate);
		base_path = "D:\\uploadFiles\\" + regdate;
		
		/*
		int year = cal.get(cal.YEAR);
		int month = cal.get(cal.MONTH) + 1;
		int date = cal.get(cal.DATE);
		
		base_path += Integer.toString(year);
		base_path += Integer.toString(month);
		base_path += Integer.toString(date);
		 */
		
		System.out.println(base_path);
		File folder = new File(base_path);
		
		if (!folder.exists()) {
			folder.mkdir();
			System.out.println("새 폴더 생성");
		} else {
			System.out.println("폴더 존재");			
		}
	}
	
	// 게시물 목록 조회(페이징)
	@Override
	public ArrayList<PostDto> post_list(SearchCriteria searchCriteria) {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		return dao.post_list(searchCriteria);
	}
	
	// 게시물 총 갯수
	@Override
	public int list_cnt(SearchCriteria searchCriteria) {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		return dao.list_cnt(searchCriteria);
	}

	// 게시물 상세 내용 조회 
	@Override
	public PostDto post_content(HashMap<String, String> param) {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		return dao.post_content(param);
	}
	
	// 게시물 조회 수 증가
	@Override
	public void update_view(HashMap<String, String> param) {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		dao.update_view(param);
	}

	// 게시물 수정
	@Override
	public void post_update(HashMap<String, String> param) {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		dao.post_update(param);
	}

	// 게시물 삭제
	@Override
	public void post_delete(HashMap<String, String> param) {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		dao.post_delete(param);
	}

	// 첨부파일 다운로드
	@Override
	public PostDto file_info(HashMap<String, String> param) throws Exception {
		PostDao dao = sqlSession.getMapper(PostDao.class);
		return dao.file_info(param);
	}

}
