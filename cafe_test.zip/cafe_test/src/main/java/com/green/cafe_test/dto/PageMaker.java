package com.green.cafe_test.dto;

import java.net.URLEncoder;

import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

public class PageMaker {
	/* 총 게시물 수 */
	private int totalCount;
	/* 시작 페이지 */
	private int startPage;
	/* 끝 페이지 */
	private int endPage;
	/* 이전, 다음 페이지 존재 여부 */
	private boolean prev;
	private boolean next;
	/* 현재 페이지와 한 페이지에 보여질 페이지 수를 구하기 위한 Criteria 클래스 */
	private Criteria criteria;
/*	
	public PageMaker() {}

	public PageMaker(int totalCount, Criteria criteria) {
		this.totalCount = totalCount;
		this.criteria = criteria;
	}
	*/
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
		calcData();
	}
	public int getStartPage() {
		return startPage;
	}
	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}
	public int getEndPage() {
		return endPage;
	}
	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}
	public boolean isPrev() {
		return prev;
	}
	public void setPrev(boolean prev) {
		this.prev = prev;
	}
	public boolean isNext() {
		return next;
	}
	public void setNext(boolean next) {
		this.next = next;
	}
	public Criteria getCriteria() {
		return criteria;
	}
	public void setCriteria(Criteria criteria) {
		this.criteria = criteria;
	}

	private void calcData() {
		int displayNum = criteria.getPerPageNum();
		endPage = (int) (Math.ceil(criteria.getPage() / (double) displayNum) * displayNum);
		startPage = (endPage - displayNum) + 1;
		
		int realEndPage = (int) (Math.ceil(totalCount / (double) displayNum));
		if (endPage > realEndPage) {
			endPage = realEndPage;
		}
		
		prev = startPage == 1 ? false: true;
		next = endPage * criteria.getPerPageNum() >= totalCount ? false: true;
	}
	
	public String makeQuery(int page) {
		UriComponents uriComponents =
				UriComponentsBuilder.newInstance()
									.queryParam("page", page)
									.queryParam("perPageNum", criteria.getPerPageNum())
									.build();
		return uriComponents.toUriString();
	}
	
	// PageMaker에서 page, perPageNum, searchType, keyword를 url로 사용할 수 있도록 하는 메소드
	public String makeSearch(int page) {
		UriComponents uriComponents =
				UriComponentsBuilder.newInstance()
									.queryParam("page", page)
									.queryParam("perPageNum", criteria.getPerPageNum())
									.queryParam("searchType", ((SearchCriteria)criteria).getSearchType())
									.queryParam("keyword", encoding(((SearchCriteria)criteria).getKeyword()))
									.build();
		return uriComponents.toUriString();
	}
	
	private String encoding(String keyword) {
		if (keyword == null || keyword.trim().length() == 0) {
			return "";
		}
		
		try {
			return URLEncoder.encode(keyword, "UTF-8");
		} catch (Exception e) {
			return "";
		}
	}
}
