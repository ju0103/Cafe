package com.green.cafe_test.controller;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.green.cafe_test.dto.MemDto;
import com.green.cafe_test.service.MemService;

@Controller
@RequestMapping("/member")
public class MemController {
	
	@Autowired
	private MemService service;
	
	@RequestMapping("/login") //�α�����
	public String login() {
		System.out.println("@@@### LOGIN()");
		
		return "member/login";
	}
	
	@RequestMapping("/loginYn") //�α��� ó�� -> MemServiceImpl.java
	public String loginYn(@RequestParam HashMap<String, String> param, HttpServletRequest request, RedirectAttributes rttr, Model model) {
		System.out.println("@@@### loginYN()");
		
		HttpSession session = request.getSession();
		int re = service.loginYn(param);
		
		if(re == 1) {
			ArrayList<MemDto> dtos = service.memberView(param);
			model.addAttribute("memberView",dtos);
			
			session.setAttribute("member_id", dtos.get(0).getMem_id());
			session.setAttribute("member_level", dtos.get(0).getMem_level());
			
			return "member/login_ok";
		}
		return "redirect:login";
	}
	
	@RequestMapping("/register") //ȸ������
	public String register() {
		System.out.println("@@@### register");
		
		return "member/register";
	}
	
	@RequestMapping("/registerOk") //���̺� insert -> MemServiceImpl.java
	public String registerOk(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### registerOk");
		service.register(param);
		
		System.out.println("ȸ����ϿϷ�->�α��� �������� �̵��˴ϴ�.");
		return "redirect:login";
	}
	
	@RequestMapping("/updateInfo") //ȸ������ ���� ��
	public String updateInfo(@RequestParam HashMap<String, String> param,Model model) {
		System.out.println("@@@### updateInfo");
		ArrayList<MemDto> dtos = service.memberView(param); 
		model.addAttribute("memberView",dtos);//ȸ�����̵�� ��ü ������ ��ȸ�ϱ� ���� �ѱ�
		return "member/updateInfo";
	}
	
	@RequestMapping("/updateInfoOk") //ȸ������ ���� ó�� update -> MemServiceImpl.java
	public String updateInfoOk(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### updateInfoOk");
		service.updateInfo(param);
		
		System.out.println("ȸ������ �����Ϸ�");
		ArrayList<MemDto> dtos = service.memberView(param);
		model.addAttribute("memberView",dtos);
		return "member/login_ok";//���� ���� �� login_ok�� ��
	}
	
	@RequestMapping("/checkInfo") //ȸ������ ��ȸ 
	public String checkInfo(@RequestParam HashMap<String, String> param,Model model) {
		System.out.println("@@@### checkInfo");
		ArrayList<MemDto> dtos = service.memberView(param);
		model.addAttribute("memberView",dtos);//ȸ�����̵�� ��ü ������ ��ȸ�ϱ� ���� �ѱ�
		return "member/checkInfo";
	}
	
	@RequestMapping("/deleteMember") //ȸ��Ż��
	public String deleteMember(@RequestParam HashMap<String, String> param, Model model, HttpSession session) {
		System.out.println("@@@### deleteMember");
		service.deleteMember(param);
		session.invalidate();
		
		System.out.println("ȸ��Ż��Ϸ�");
		return "redirect:login";
	}
	
}
